#!/usr/bin/python3
"""Empty init for packaging."""
