#!/usr/bin/python3
"""Set version attribute."""
__version__ = "1.9.1"
